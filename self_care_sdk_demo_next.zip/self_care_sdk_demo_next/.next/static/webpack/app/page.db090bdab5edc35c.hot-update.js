/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
self["webpackHotUpdate_N_E"]("app/page",{

/***/ "(app-pages-browser)/./src/app/page.module.css":
/*!*********************************!*\
  !*** ./src/app/page.module.css ***!
  \*********************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

eval(__webpack_require__.ts("// extracted by mini-css-extract-plugin\nmodule.exports = {\"main\":\"page_main__GlU4n\",\"description\":\"page_description__86bsR\",\"code\":\"page_code__9lUUd\",\"grid\":\"page_grid__f5Kdy\",\"card\":\"page_card__QV0Om\",\"center\":\"page_center__5oHG7\",\"logo\":\"page_logo__7fc9l\",\"content\":\"page_content__kDoxQ\",\"vercelLogo\":\"page_vercelLogo__rOY_u\",\"rotate\":\"page_rotate__durgN\"};\n    if(true) {\n      // 1719379724292\n      var cssReload = __webpack_require__(/*! ./node_modules/next/dist/compiled/mini-css-extract-plugin/hmr/hotModuleReplacement.js */ \"(app-pages-browser)/./node_modules/next/dist/compiled/mini-css-extract-plugin/hmr/hotModuleReplacement.js\")(module.id, {\"publicPath\":\"/_next/\",\"esModule\":false,\"locals\":true});\n      module.hot.dispose(cssReload);\n      \n    }\n  \nmodule.exports.__checksum = \"ddfae594b064\"\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwcC1wYWdlcy1icm93c2VyKS8uL3NyYy9hcHAvcGFnZS5tb2R1bGUuY3NzIiwibWFwcGluZ3MiOiJBQUFBO0FBQ0Esa0JBQWtCO0FBQ2xCLE9BQU8sSUFBVTtBQUNqQjtBQUNBLHNCQUFzQixtQkFBTyxDQUFDLHdNQUFrSixjQUFjLHNEQUFzRDtBQUNwUCxNQUFNLFVBQVU7QUFDaEI7QUFDQTtBQUNBO0FBQ0EseUJBQXlCIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vX05fRS8uL3NyYy9hcHAvcGFnZS5tb2R1bGUuY3NzP2ZjMWYiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gZXh0cmFjdGVkIGJ5IG1pbmktY3NzLWV4dHJhY3QtcGx1Z2luXG5tb2R1bGUuZXhwb3J0cyA9IHtcIm1haW5cIjpcInBhZ2VfbWFpbl9fR2xVNG5cIixcImRlc2NyaXB0aW9uXCI6XCJwYWdlX2Rlc2NyaXB0aW9uX184NmJzUlwiLFwiY29kZVwiOlwicGFnZV9jb2RlX185bFVVZFwiLFwiZ3JpZFwiOlwicGFnZV9ncmlkX19mNUtkeVwiLFwiY2FyZFwiOlwicGFnZV9jYXJkX19RVjBPbVwiLFwiY2VudGVyXCI6XCJwYWdlX2NlbnRlcl9fNW9IRzdcIixcImxvZ29cIjpcInBhZ2VfbG9nb19fN2ZjOWxcIixcImNvbnRlbnRcIjpcInBhZ2VfY29udGVudF9fa0RveFFcIixcInZlcmNlbExvZ29cIjpcInBhZ2VfdmVyY2VsTG9nb19fck9ZX3VcIixcInJvdGF0ZVwiOlwicGFnZV9yb3RhdGVfX2R1cmdOXCJ9O1xuICAgIGlmKG1vZHVsZS5ob3QpIHtcbiAgICAgIC8vIDE3MTkzNzk3MjQyOTJcbiAgICAgIHZhciBjc3NSZWxvYWQgPSByZXF1aXJlKFwiL1VzZXJzL3Zpa3JhbTIucGFyaWhhci9Eb2N1bWVudHMvR0lUL3NlbGZfY2FyZV9zZGtfZGVtb19uZXh0L25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvY29tcGlsZWQvbWluaS1jc3MtZXh0cmFjdC1wbHVnaW4vaG1yL2hvdE1vZHVsZVJlcGxhY2VtZW50LmpzXCIpKG1vZHVsZS5pZCwge1wicHVibGljUGF0aFwiOlwiL19uZXh0L1wiLFwiZXNNb2R1bGVcIjpmYWxzZSxcImxvY2Fsc1wiOnRydWV9KTtcbiAgICAgIG1vZHVsZS5ob3QuZGlzcG9zZShjc3NSZWxvYWQpO1xuICAgICAgXG4gICAgfVxuICBcbm1vZHVsZS5leHBvcnRzLl9fY2hlY2tzdW0gPSBcImRkZmFlNTk0YjA2NFwiXG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(app-pages-browser)/./src/app/page.module.css\n"));

/***/ })

});