import { SDK } from "@oblo/selfcare-sdk";

class Oblo {
  sdk = null;
  constructor() {
    this.run();
  }

  async run() {
    try {
      this.sdk = new SDK(
        "oblo",
        {
          apiKey: process.env.NEXT_PUBLIC_API_KEY,
          apiVersion: process.env.NEXT_PUBLIC_API_VERSION,
          port: process.env.NEXT_PUBLIC_CLOUD_PORT,
          url: process.env.NEXT_PUBLIC_CLOUD_URL,
        },
        { port: process.env.NEXT_PUBLIC_MQTT_PORT, url: process.env.NEXT_PUBLIC_MQTT_URL }
      );
      await this.sdk.init();
    } catch (err) {
      console.error("Failed to initialize", err);
    }
  }

  getSDK() {
    return this.sdk;
  }
}

export default new Oblo();

// let obj = new Oblo();


